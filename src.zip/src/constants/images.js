const cat1 = require('../assets/images/cat1.png');
const cat2 = require('../assets/images/cat2.png');
const cat3 = require('../assets/images/cat3.png');
const cat4 = require('../assets/images/cat4.png');

const cate1 = require('../assets/images/cate1.png');
const cate2 = require('../assets/images/cate2.png');
const cate3 = require('../assets/images/cate3.png');

const home1 = require('../assets/images/home1.png');
const home2 = require('../assets/images/home2.png');

const homelist1 = require('../assets/images/homelist1.png');
const homelist2 = require('../assets/images/homelist2.png');

const contact1 = require('../assets/images/contact1.png');
const contact2 = require('../assets/images/contact2.png');
const file = require('../assets/images/file.png');

const onboard1 = require('../assets/images/onboard1.png');
const onboard2 = require('../assets/images/onboard2.png');
const onboard3 = require('../assets/images/onboard3.png');

const profile1 = require('../assets/images/profile1.png');
const profile2 = require('../assets/images/profile2.png');
const profile3 = require('../assets/images/profile3.png');

const wire = require('../assets/images/wire.png');
const ytube = require('../assets/images/ytube.png');

const profilebg = require('../assets/images/profilebg.png');
const drawbg = require('../assets/images/drawbg.png');
const idea = require('../assets/images/idea.png');

const green = require('../assets/images/green.png');
const faqimg = require('../assets/images/faqimg.png');
const mooxylogo = require('../assets/images/mooxylogo.png');

const course1 = require('../assets/images/course1.png');
const course2 = require('../assets/images/course2.png');
const course3 = require('../assets/images/course3.png');
const course4 = require('../assets/images/course4.png');
const course5 = require('../assets/images/course5.png');

const person1 = require('../assets/images/person1.png');
const person2 = require('../assets/images/person2.png');

const wallet = require('../assets/images/wallet.png');
const online = require('../assets/images/online.png');

const placed = require('../assets/images/placed.png');
const community = require('../assets/images/community.png');
const learn = require('../assets/images/learn.png');

const learn1 = require('../assets/images/learn1.png');
const learn2 = require('../assets/images/learn2.png');
const refer = require('../assets/images/refer.png');

const notes = require('../assets/images/notes.png');

const quiz = require('../assets/images/quiz.png');
const practice = require('../assets/images/practice.png');
const quizbg = require('../assets/images/quizbg.png');
const accountsuc = require('../assets/images/accountsuc.png');

export default {
  cat1,
  cat2,
  cat3,
  cat4,

  cate1,
  cate2,
  cate3,

  home1,
  home2,
  homelist1,
  homelist2,
  contact1,
  contact2,

  file,

  onboard1,
  onboard2,
  onboard3,
  profile1,
  profile2,
  profile3,
  wire,
  ytube,
  profilebg,
  drawbg,
  idea,
  green,
  faqimg,
  mooxylogo,
  course1,
  course2,
  course3,
  course4,
  course5,
  person1,
  person2,
  wallet,
  online,
  placed,
  community,
  learn,
  learn1,
  learn2,
  refer,
  notes,
  quiz,
  practice,
  quizbg,
  accountsuc,
};
