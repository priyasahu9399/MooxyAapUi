const a_notify = require('../assets/icons/a_notify.png');
const bhome = require('../assets/icons/bhome.png');
const camera = require('../assets/icons/camera.png');
const ccs = require('../assets/icons/ccs.png');
const community = require('../assets/icons/community.png');
const dob = require('../assets/icons/dob.png');
const email = require('../assets/icons/email.png');
const larrow = require('../assets/icons/larrow.png');
const learning = require('../assets/icons/learning.png');
const location2 = require('../assets/icons/location2.png');
const notify1 = require('../assets/icons/notify1.png');
const pa = require('../assets/icons/pa.png');
const phone = require('../assets/icons/phone.png');
const rarrow1 = require('../assets/icons/rarrow1.png');
const store = require('../assets/icons/store.png');
const back = require('../assets/icons/back.png');
const cart = require('../assets/icons/cart.png');
const contact = require('../assets/icons/contact.png');
const darrow = require('../assets/icons/darrow.png');
const deliver = require('../assets/icons/deliver.png');

const dcart = require('../assets/icons/dcart.png');
const dcontact = require('../assets/icons/dcontact.png');
const dhome = require('../assets/icons/dhome.png');
const di = require('../assets/icons/di.png');
const dorder = require('../assets/icons/dorder.png');
const dque = require('../assets/icons/dque.png');
const dreturn = require('../assets/icons/dreturn.png');
const dstar = require('../assets/icons/dstar.png');

const heart = require('../assets/icons/heart.png');
const home = require('../assets/icons/home.png');
const heart1 = require('../assets/icons/heart1.png');
const heart3 = require('../assets/icons/heart3.png');
const i_icon = require('../assets/icons/i_icon.png');
const location = require('../assets/icons/location.png');
const logout = require('../assets/icons/logout.png');
const privacy = require('../assets/icons/privacy.png');
const que = require('../assets/icons/que.png');
const returns = require('../assets/icons/return.png');
const rarrow = require('../assets/icons/rarrow.png');
const right = require('../assets/icons/right.png');
const search = require('../assets/icons/search.png');
const user = require('../assets/icons/user.png');
const watch = require('../assets/icons/watch.png');
const x = require('../assets/icons/x.png');
const notify = require('../assets/icons/notify.png');
const toggle = require('../assets/icons/toggle.png');
const star = require('../assets/icons/star.png');
const bag = require('../assets/icons/bag.png');
const wallet = require('../assets/icons/wallet.png');
const starw = require('../assets/icons/starw.png');
const help = require('../assets/icons/help.png');
const queicon = require('../assets/icons/queicon.png');
const myorder = require('../assets/icons/myorder.png');
const iicon = require('../assets/icons/iicon.png');
const term = require('../assets/icons/term.png');
const share = require('../assets/icons/share.png');
const allfile = require('../assets/icons/allfile.png');
const files = require('../assets/icons/files.png');
const fileattach = require('../assets/icons/fileattach.png');
const fileattach2 = require('../assets/icons/fileattach2.png');
const pdf = require('../assets/icons/pdf.png');
const clock = require('../assets/icons/clock.png');
const send = require('../assets/icons/send.png');
const smile = require('../assets/icons/smile.png');
const smile2 = require('../assets/icons/smile2.png');
const smile3 = require('../assets/icons/smile3.png');
const gif = require('../assets/icons/gif.png');
const mice = require('../assets/icons/mice.png');
const emptystar = require('../assets/icons/emptystar.png');
const team = require('../assets/icons/team.png');
const vision = require('../assets/icons/vision.png');
const mission = require('../assets/icons/mission.png');
const transfer = require('../assets/icons/transfer.png');
const plus = require('../assets/icons/plus.png');
const video = require('../assets/icons/video.png');
const offerref = require('../assets/icons/offerref.png');
const lock = require('../assets/icons/lock.png');
const gift = require('../assets/icons/gift.png');
const like = require('../assets/icons/like.png');
const c_eye = require('../assets/icons/c_eye.png');
const hiii = require('../assets/icons/hiii.png');
const course = require('../assets/icons/course.png');
const batch = require('../assets/icons/batch.png');
const eduction = require('../assets/icons/eduction.png');
const notes = require('../assets/icons/notes.png');
const practice = require('../assets/icons/practice.png');
const quiz = require('../assets/icons/quiz.png');
const lock2 = require('../assets/icons/lock2.png');
const yarrow = require('../assets/icons/yarrow.png');
const sad = require('../assets/icons/sad.png');


const sim1 = require('../assets/icons/sim1.png');
const sim2 = require('../assets/icons/sim2.png');

export default {
  a_notify,
  bhome,
  camera,
  ccs,
  community,
  dob,
  email,
  larrow,
  learning,
  location2,
  notify1,
  pa,
  phone,
  rarrow1,
  store,
  back,
  cart,
  location,
  darrow,
  deliver,
  dcart,
  dcontact,
  dhome,
  di,
  dorder,
  dque,
  dreturn,
  dstar,
  heart,
  home,
  heart1,
  heart3,
  i_icon,
  contact,
  logout,
  privacy,
  que,
  returns,
  right,
  rarrow,
  search,
  user,
  watch,
  x,
  notify,
  toggle,
  star,
  bag,
  wallet,
  starw,
  help,
  queicon,
  myorder,
  iicon,
  term,
  share,
  allfile,
  files,
  fileattach,
  fileattach2,
  pdf,
  clock,
  send,
  smile,
  smile2,
  smile3,
  gif,
  mice,
  emptystar,
  team,
  vision,
  mission,
  transfer,
  plus,
  video,
  offerref,
  lock,
  gift,
  like,
  c_eye,
  hiii,
  course,
  batch,
  eduction,
  notes,
  practice,
  quiz,
  lock2,
  yarrow,
  sad,
  sim1,
  sim2
};
